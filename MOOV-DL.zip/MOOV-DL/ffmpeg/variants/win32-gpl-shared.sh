#!/bin/bash
source "$(dirname "$BASH_SOURCE")"/default-install-shared.sh
source "$(dirname "$BASH_SOURCE")"/defaults-gpl-shared.sh
